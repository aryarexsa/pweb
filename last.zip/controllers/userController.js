const User = require('../models/User');

exports.dashboard = async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.redirect('/auth/login');
    }

    const user = await User.findById(req.session.userId);

    if (!user) {
      return res.status(404).send('User not found');
    }

    res.render('dashboard', { user, notifications: user.notifications });
  } catch (err) {
    console.error('Error loading dashboard:', err);
    res.status(500).send('Error loading dashboard.');
  }
};

exports.giveSign = async (req, res) => {
  try {
    const { notificationId } = req.body;

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const notification = user.notifications.id(notificationId);
    if (!notification) {
      return res.status(404).json({ error: 'Notification not found' });
    }

    const requesterUserId = notification.message.split(' ')[3]; 
    const requesterUser = await User.findById(requesterUserId);

    if (!requesterUser) {
      return res.status(404).json({ error: 'Requester user not found' });
    }

    user.pendingSigns = user.pendingSigns.filter(
      (sign) => sign.fromUser.toString() !== requesterUserId
    );

    requesterUser.notifications.push({
      message: `User with ID ${user._id} has given you a signature.`,
      isRead: false,
    });

    await user.save();
    await requesterUser.save();
    notification.isRead = true;
    await user.save();

    res.json({ success: true, message: 'Sign given successfully.' });
  } catch (error) {
    console.error('Error in giveSign:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.markSignAsGiven = async (req, res) => {
  try {
    const { signId } = req.body;

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const sign = user.givenSigns.id(signId);
    if (!sign) {
      return res.status(404).json({ error: 'Sign not found' });
    }

    sign.isCompleted = true;
    await user.save();

    res.json({ success: true, message: 'Sign marked as given.' });
  } catch (error) {
    console.error('Error in markSignAsGiven:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.uploadSignature = async (req, res) => {
  try {
    const { signatureData } = req.body;

    if (!signatureData) {
      return res.status(400).send('Signature data is missing.');
    }

    res.redirect('/user/dashboard');
  } catch (err) {
    console.error('Error uploading signature:', err);
    res.status(500).send('Error uploading signature.');
  }
};

exports.searchUser = async (req, res) => {
  try {
    const { username } = req.query;

    const users = await User.find({ username: new RegExp(username, 'i') });
    res.json(users);
  } catch (err) {
    console.error('Error searching for users:', err);
    res.status(500).send('Error searching for users.');
  }
};

exports.requestSignature = async (req, res) => {
  try {
    const { userId, targetUserId } = req.body;

    if (!userId || !targetUserId) {
      return res.status(400).json({ error: 'Missing userId or targetUserId' });
    }

    const targetUser = await User.findById(targetUserId);

    if (!targetUser) {
      return res.status(404).json({ error: 'Target user not found' });
    }

    targetUser.notifications.push({
      message: `User with ID ${userId} has requested your signature.`,
      isRead: false,
    });

    await targetUser.save();

    res.status(200).json({ message: 'Signature request sent successfully' });
  } catch (err) {
    console.error('Error in requestSignature:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.markNotificationAsRead = async (req, res) => {
  try {
    const { notificationId } = req.body;

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const notification = user.notifications.id(notificationId);
    if (!notification) {
      return res.status(404).json({ error: 'Notification not found' });
    }

    notification.isRead = true;
    await user.save();

    res.status(200).json({ message: 'Notification marked as read' });
  } catch (err) {
    console.error('Error marking notification as read:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};
