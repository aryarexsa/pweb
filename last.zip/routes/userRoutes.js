const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const User = require('../models/User');

router.get('/dashboard', userController.dashboard);
router.post('/upload-signature', userController.uploadSignature);
router.get('/search', userController.searchUser);
router.post('/give-sign', userController.giveSign);
router.post('/mark-sign-as-given', userController.markSignAsGiven);

router.post('/mark-notification-as-read', async (req, res) => {
    try {
      const { notificationId } = req.body;
  
      const user = await User.findById(req.session.userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      const notification = user.notifications.id(notificationId);
      if (!notification) {
        return res.status(404).json({ error: 'Notification not found' });
      }
  
      notification.isRead = true;
      await user.save();
  
      res.json({ success: true });
    } catch (error) {
      console.error('Error marking notification as read:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  router.post('/request-signature', async (req, res) => {
    try {
        const { userId, targetUserId } = req.body;

        if (!userId || !targetUserId) {
            return res.status(400).json({ error: 'Missing userId or targetUserId' });
        }

        console.log(`Processing signature request from userId: ${userId} to targetUserId: ${targetUserId}`);

        const targetUser = await User.findById(targetUserId);

        if (!targetUser) {
            return res.status(404).json({ error: 'Target user not found' });
        }

        targetUser.notifications.push({
            message: `User with ID ${userId} has requested your signature.`,
            isRead: false,
        });

        await targetUser.save();

        res.status(200).json({ message: 'Signature request sent successfully' });
    } catch (error) {
        console.error('Error handling request:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


module.exports = router;
